// script.js
let cart = [];

function addToCart(productId) {
  // In a real-world scenario, you would handle product addition logic here.
  cart.push(productId);
  updateCart();
}

function updateCart() {
  const cartElement = document.getElementById('cart');
  cartElement.textContent = `Cart (${cart.length} items)`;
}
